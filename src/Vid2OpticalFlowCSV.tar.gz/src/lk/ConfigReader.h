#pragma once

class ConfigReader
{
public:
	void Read(const char* filename);


};
