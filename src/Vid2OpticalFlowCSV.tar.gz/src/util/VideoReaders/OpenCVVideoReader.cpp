#include "stdafx.h"
#include "OpenCVVideoReader.h"

OpenCVVideoReader::OpenCVVideoReader(void)
{
}

OpenCVVideoReader::~OpenCVVideoReader(void)
{
}
